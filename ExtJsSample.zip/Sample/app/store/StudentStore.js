Ext.define('School.store.StudentStore',
{
    extend: 'Ext.data.Store',
    model: 'School.model.Student',
    autoLoad: false,
    storeId: 'Student'
});